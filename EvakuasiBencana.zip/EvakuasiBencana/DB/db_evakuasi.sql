-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2021 at 10:30 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_evakuasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `username`, `password`, `token`) VALUES
(1, 'admin', '$2y$10$sUiT9N14EUVPfPB76ng/rO/rQw1BcEqeK6ziSIyARRjM7usee.OKa', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2RiX2V2YWt1YXNpIiwiYXVkIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9kYl9ldmFrdWFzaSIsImlhdCI6MTYxNjA1Mjg2OCwiZXhwIjoxNjE2MDU2NDY4LCJkYXRhIjp7InVzZXJfaWQiOiIxIn19.dSIDwuxDnXT4EaM1vy8UX0f3LEr6vd2lz-GDQZx7dXM');

-- --------------------------------------------------------

--
-- Table structure for table `tb_bencana`
--

CREATE TABLE `tb_bencana` (
  `id_bencana` int(11) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `kecamatan` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lgt` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_bencana`
--

INSERT INTO `tb_bencana` (`id_bencana`, `alamat`, `kecamatan`, `lat`, `lgt`, `kategori`) VALUES
(1, 'Batu busuk', 'Pauh', '-0.922877', '100.4444214', '2'),
(2, 'Beringin', 'Lubuk Kilangan', '-0.9721405', '100.4280644', '2'),
(3, 'Gurun Laweh', 'Lubuk Begalung', '-0.961068', '100.3918508', '2'),
(4, 'Jl. Samudra Belakang Tangsi', 'Padang Barat', '-0.9570834', '100.3512016', '5'),
(5, 'Jl. Muara, Berok Nipah', 'Padang Barat', '-0.9620401', '100.3526489', '5'),
(6, 'Purus', 'Padang Barat', '-0.9452322', '100.3514743', '5'),
(7, 'Pantai Muaro Lasak', 'Padang Barat', '-0.9286721', '100.3482688', '5'),
(8, 'Jl. Samudera No.1, Purus', 'Padang Barat', '-0.9367999', '100.3522373', '5'),
(9, 'Jl. Sumatera, Ulak Karang Utara', 'Padang Utara', '-0.9072179', '100.3428243', '5'),
(10, 'Jl. Parkit VI, Air Tawar Barat', 'Padang Utara', '-0.9001833', '100.3435844', '5'),
(11, 'Jl. Gajah III Air Tawar Barat', 'Padang Utara', '-0.8959642', '100.3435374', '5'),
(12, 'Gurun laweh', 'Nanggalo', '-0.9088627', '100.3752712', '1'),
(13, 'Surau Gadang', 'Nanggalo', '-0.8992773', '100.3654747', '1'),
(15, 'Dadok Tunggul Hitam', 'Koto Tangah', '-0.8779719', '100.3592892', '1'),
(16, 'Tabiang banda gadang', 'Nanggalo', '-0.9129101', '100.3749674', '1'),
(17, 'Sitinjau lauik', 'Lubuk kilangan', '-0.9514749', '100.5041801', '4'),
(18, 'Jl Raya Air Dingin Lubuk Minturun ', 'Koto Tangah', '-0.8089046', '100.4060284', '4'),
(19, 'Bungus Teluk Kabung', 'Bungus Teluk Kabung', '-1.045306', '100.415451', '4'),
(20, 'Kurao Pagang', 'Nanggalo', '-0.8896586', '100.362254', '1'),
(21, 'Ulak Karang Utara', 'Padang Utara', '-0.905189', '100.3477081', '1'),
(22, 'Air Tawar Barat', 'Padang Utara', '-0.9034913', '100.3481047', '1'),
(23, 'Bungo Pasang', 'Koto Tangah', '-0.8607562', '100.3408136', '1'),
(24, 'Pasia Nan Tigo', 'Koto Tangah', '-0.8618482', '100.3371851', '1'),
(25, 'Kampong Baru Nan XX', 'Lubuk Begalung', '-0.9576313', '100.4129561', '2'),
(26, 'Air Pacah', 'Koto Tangah', '-0.8657765', '100.3655974', '2'),
(27, 'Dadok Tunggul Hitam', 'Koto Tangah', '-0.8779719', '100.3592892', '2'),
(28, 'Padang Besi', 'Lubuk Kilangan', '-0.9535801', '100.4458387', '2'),
(29, 'Ganting Parak Gadang', 'Padang Timur', '-0.9524104', '100.3657322', '2'),
(30, 'Jati', 'Padang Timur', '-0.9361155', '100.3613903', '2'),
(31, 'Jl. Bundo Kanduang', 'Padang Barat', '-0.9544926', '100.3571834', '5'),
(32, 'Jl. Kampung Dobi', 'Padang Barat', '-0.9547548', '100.3551658', '5'),
(33, 'Jl. Hamka, Air Tawar', 'Padang Utara', '-0.9016703', '100.3486093', '5');

-- --------------------------------------------------------

--
-- Table structure for table `tb_evakuasi`
--

CREATE TABLE `tb_evakuasi` (
  `id_evakuasi` int(11) NOT NULL,
  `tempat_evakuasi` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `kecamatan` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lgt` varchar(255) NOT NULL,
  `daya_tampung` varchar(255) NOT NULL,
  `kategori` int(11) NOT NULL,
  `jarak` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_evakuasi`
--

INSERT INTO `tb_evakuasi` (`id_evakuasi`, `tempat_evakuasi`, `alamat`, `kecamatan`, `lat`, `lgt`, `daya_tampung`, `kategori`, `jarak`) VALUES
(1, 'Lapangan imam bonjol', 'Bagindo aziz chan', 'Padang Selatan', '-0.9524403', '100.3608588', '2000', 3, 3161.0712845080357),
(2, 'GOR H. Agus Salim', 'Rimbo kaluang', 'Padang Barat', '-0.929340', '100.358010', '2000', 3, 4343.330032121982),
(5, 'Lapangan Gubernur', 'Bandar Purus', 'Padang Barat', '-0.9356128', '100.3558675', '1000', 3, 4175.482639152458),
(6, 'Lapangan Polda Sumbar', 'Jendral Sudirman', 'Padang Barat', '-0.9360865', '100.3587197', '1000', 3, 3870.492443486858),
(9, 'AMIK Indonesia', 'Jl.Khatib Sulaiman', 'Padang Utara', '-0.9137146', '100.3559253', '2000', 5, 5708.857652264278),
(12, 'Bappeda Prov. Sumbar', 'Jl. Khatib Sulaiman', 'Padang Barat', '-0.9257988', '100.3588886', '2000', 5, 4516.512133421126),
(13, 'Bukit di Air Manis', 'Air Manis', 'Padang Selatan', '-0.9897317', '100.3638474', '3000', 5, 4991.960531470164),
(16, 'Bukit di Lantamal II', 'Lantamal II Teluk Bayur', 'Padang Selatan', '-1.0036799', '100.3645023', '2000', 5, 6299.011135644493);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Banjir Bandang'),
(2, 'Banjir'),
(3, 'Gempa'),
(4, 'Longsor'),
(5, 'Tsunami');

-- --------------------------------------------------------

--
-- Table structure for table `tb_komentar`
--

CREATE TABLE `tb_komentar` (
  `id_komentar` int(11) NOT NULL,
  `isi_komentar` varchar(256) NOT NULL,
  `tgl_komentar` date NOT NULL,
  `jam_komentar` time NOT NULL,
  `kategori` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_komentar`
--

INSERT INTO `tb_komentar` (`id_komentar`, `isi_komentar`, `tgl_komentar`, `jam_komentar`, `kategori`) VALUES
(17, 'test', '2021-03-10', '15:10:07', 1),
(18, 'NOoooo', '2020-12-31', '15:10:07', 1),
(19, 'Yesssssssss', '2021-03-10', '18:10:05', 3),
(20, 'Yesssssssss', '2020-11-30', '15:10:05', 3),
(21, 'YesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYesssssssssYes', '2021-03-10', '18:10:05', 3),
(22, 'semoga berhasil', '2021-03-18', '15:15:12', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tb_bencana`
--
ALTER TABLE `tb_bencana`
  ADD PRIMARY KEY (`id_bencana`);

--
-- Indexes for table `tb_evakuasi`
--
ALTER TABLE `tb_evakuasi`
  ADD PRIMARY KEY (`id_evakuasi`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_komentar`
--
ALTER TABLE `tb_komentar`
  ADD PRIMARY KEY (`id_komentar`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_bencana`
--
ALTER TABLE `tb_bencana`
  MODIFY `id_bencana` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tb_evakuasi`
--
ALTER TABLE `tb_evakuasi`
  MODIFY `id_evakuasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_komentar`
--
ALTER TABLE `tb_komentar`
  MODIFY `id_komentar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
