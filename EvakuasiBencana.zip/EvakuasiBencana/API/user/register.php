<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if($_SERVER["REQUEST_METHOD"] != "POST"){
    $returnData = msg(0,404,'Page Not Found');
}else if (!isset($_POST['username']) || !isset($_POST['password']) || empty(trim($_POST['username'])) || empty(trim($_POST['password']))
) {
    $returnData = msg(0,422,'Isi field username dan password');
}else {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $token = "";
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $query = "INSERT INTO tb_admin(username,password,token) 
              VALUES(:uname,:pwd,:token)";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(":uname",$username);
    $stmt->bindParam(":pwd",$hash);
    $stmt->bindParam(":token", $token);
    $stmt->execute();

    $returnData = msg(1,200,'Register Berhasil');

}

echo json_encode($returnData);
?>