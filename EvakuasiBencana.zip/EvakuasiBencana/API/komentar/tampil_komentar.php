<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';
include_once '../class/jwthandler.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "GET") {
    $returnData = msg(0,404,'Page Not Found');
}else {
    $tanggal = $_GET['tanggal'];

    $query = "SELECT kom.*, kt.* FROM tb_komentar kom
            LEFT JOIN tb_kategori kt 
            ON kom.kategori = kt.id_kategori
            WHERE kom.tgl_komentar = :tanggal
            ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":tanggal", $tanggal);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            
            $item = array(
                "tanggal" => $row['tgl_komentar'],
                "jam" => $row['jam_komentar'],
                "komentar" => $row['isi_komentar'],
                "kategori" => $row['id_kategori']
            );

            array_push($data["DATA"], $item);
        }

        $returnData = msg(1,200,'Data Ada',$data);
    }else {
        $returnData = msg(0,201,'Data tidak ada');
    }

    
}

echo json_encode($returnData);
?>