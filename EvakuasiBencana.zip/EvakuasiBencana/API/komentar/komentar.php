<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: POST");
    header("Content-Type: application/json, charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    function msg($success,$status,$message,$extra = []){
        return array_merge([
            'success' => $success,
            'status' => $status,
            'message' => $message
        ],$extra);
    }
    
    include_once '../class/database.php';
    include_once '../class/jwthandler.php';
    
    $database = new Database();
    $conn = $database->dbConnection();
    
    $returnData = [];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $returnData = msg(0,404,'Page Not Found');
    }else if ( !isset($_POST['isi']) || !isset($_POST['tgl']) || !isset($_POST['kategori']) ||
                empty(trim($_POST['isi'])) || empty(trim($_POST['tgl'])) || empty(trim($_POST['kategori']))
    ) {
        $returnData = msg(0,422,'Isi Semua Field');
    }else {
        $isi = $_POST['isi'];
        $tgl = $_POST['tgl'];
        $jam = $_POST['jam'];
        $kategori = $_POST['kategori'];

        $query = "INSERT INTO tb_komentar(isi_komentar,tgl_komentar,jam_komentar,kategori) VALUES(:isi,:tgl,:jam,:kategori)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":isi", $isi);
        $stmt->bindParam(":tgl", $tgl);
        $stmt->bindParam(":jam", $jam);
        $stmt->bindParam(":kategori", $kategori);
        $stmt->execute();

        $returnData = msg(1,200,'Input Data Berhasil');
        
    }

    
echo json_encode($returnData);
?>