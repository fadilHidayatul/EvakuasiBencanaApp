<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';
include_once '../class/jwthandler.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif ( !isset($_POST['kategori']) || empty(trim($_POST['kategori']))
) {
    $returnData = msg(0,422,'Harap Isi Semua Field');
}else{
    $kategori = $_POST['kategori'];

    $query = "SELECT e.*, k.* FROM tb_evakuasi e
    LEFT JOIN tb_kategori k ON e.kategori = k.id_kategori
    WHERE kategori = :kat ORDER BY e.jarak ASC";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":kat", $kategori);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $item = array(
                "id" => $row['id_evakuasi'],
                "kategori_bencana" => $row['nama_kategori'],
                "tempat" => $row['tempat_evakuasi'],
                "alamat" => $row['alamat'],
                "kecamatan" => $row['kecamatan'],
                "lat" => $row['lat'],
                "long" => $row['lgt'],
                "daya" => $row['daya_tampung'],
                "jarak" =>$row['jarak']
            );

            array_push($data["DATA"],$item);
        }

        $returnData = msg(1,200,'Data ada',$data);
    }else{
        $returnData = msg(1,201,'Data tidak ada');
    }
}

echo json_encode($returnData);
?>