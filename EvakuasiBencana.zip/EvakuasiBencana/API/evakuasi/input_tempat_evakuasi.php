<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';
include_once '../class/jwthandler.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif ( !isset($_POST['tempat']) || !isset($_POST['alamat']) || !isset($_POST['kecamatan']) ||!isset($_POST['lat']) || !isset($_POST['lgt']) || !isset($_POST['daya']) || !isset($_POST['kategori']) ||
         empty(trim($_POST['tempat']))|| empty(trim($_POST['alamat']))|| empty(trim($_POST['kecamatan']))||empty(trim($_POST['lat']))|| empty(trim($_POST['lgt']))|| empty(trim($_POST['daya']))|| empty(trim($_POST['kategori']))
) {
    $returnData = msg(0,422,'Harap isi semua field ');
}else {
    $tempat = $_POST['tempat'];
    $alamat = $_POST['alamat'];
    $kecamatan = $_POST['kecamatan'];
    $lat = $_POST['lat'];
    $long = $_POST['lgt'];
    $daya = $_POST['daya'];
    $kategori = $_POST['kategori'];

    $query = "INSERT INTO tb_evakuasi(tempat_evakuasi,alamat,kecamatan,lat,lgt,daya_tampung,kategori)
              VALUES(:tempat,:alamat,:kec,:lat,:lgt,:daya,:kategori) ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":tempat", $tempat);
    $stmt->bindParam(":alamat", $alamat);
    $stmt->bindParam(":kec", $kecamatan);
    $stmt->bindParam(":lat", $lat);
    $stmt->bindParam(":lgt", $long);
    $stmt->bindParam(":daya", $daya);
    $stmt->bindParam(":kategori", $kategori);
    $stmt->execute();

    $returnData = msg(1,200,'Input Tempat Evakuasi Berhasil');
}

echo json_encode($returnData);
?>