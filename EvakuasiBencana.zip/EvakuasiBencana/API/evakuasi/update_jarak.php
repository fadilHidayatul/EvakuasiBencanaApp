<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: POST");
    header("Content-Type: application/json, charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    function msg($success,$status,$message,$extra = []){
        return array_merge([
            'success' => $success,
            'status' => $status,
            'message' => $message
        ],$extra);
    }
    
    include_once '../class/database.php';
    include_once '../class/jwthandler.php';
    
    $database = new Database();
    $conn = $database->dbConnection();
    
    $returnData = [];

    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        $returnData = msg(0,404,'Page Not Found');
    }elseif ( !isset($_POST['jarak']) || empty(trim($_POST['jarak'])) || !isset($_POST['id_tempat']) || empty(trim($_POST['id_tempat']))
    ) {
        $returnData = msg(0,422,'Harap Isi Semua Field');
    }else {
        $jarak = $_POST['jarak'];
        $id_tempat = $_POST['id_tempat'];

        $query = "UPDATE tb_evakuasi SET jarak = :jarak WHERE id_evakuasi = :id_tempat";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":jarak", $jarak);
        $stmt->bindParam(":id_tempat", $id_tempat);
        $stmt->execute();

        $returnData = msg(1,200,'Update Jarak tempat berhasil');
    }

echo json_encode($returnData);
?>