<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}else if (!isset($_POST['alamat']) ||!isset($_POST['kecamatan']) || !isset($_POST['lat']) || !isset($_POST['long']) || !isset($_POST['kategori']) ||
         empty(trim($_POST['alamat'])) || empty(trim($_POST['kecamatan'])) ||empty(trim($_POST['lat'])) || empty(trim($_POST['long'])) || empty(trim($_POST['kategori']))
) {
    $returnData = msg(0,422,'Isi Semua Data');
}else{
    $alamat = $_POST['alamat'];
    $kecamatan = $_POST['kecamatan'];
    $lat = $_POST['lat'];
    $long = $_POST['long'];
    $kategori = $_POST['kategori'];

    $query = "INSERT INTO tb_bencana(alamat,kecamatan,lat,lgt,kategori) 
              VALUES(:alamat, :kec, :lat, :lgt, :kategori) ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":alamat", $alamat);
    $stmt->bindParam(":kec", $kecamatan);
    $stmt->bindParam(":lat", $lat);
    $stmt->bindParam(":lgt", $long);
    $stmt->bindParam(":kategori", $kategori);
    $stmt->execute();

    $returnData = msg(1,200,'Input Titik Bencana Berhasil');

}

echo json_encode($returnData);
?>